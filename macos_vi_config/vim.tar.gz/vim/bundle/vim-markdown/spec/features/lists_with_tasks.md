Stars
* [ ] First tasks item
* [x] Second tasks item
* [ ] Third tasks item


Dashes
- [x] First tasks item
- [ ] Second tasks item
- [x] Third tasks item


Pluses
+ [x] First tasks item
+ [x] Second tasks item
+ [ ] Third tasks item


Ordered
1. [ ] First tasks item
2. [x] Second tasks item
3. [x] Third tasks item

* [] This is not a task list item because the space between the brackets is mandatory for a non completed task
* [*] This is not a task list item because the `x` is the only allowed character to mark a task as done
* [ ]This is not a task list item because the space after the brackets is mandatory
* [x]This is not a task list item because the space after the brackets is mandatory

Aside from that task lists behaves in the same way as the simple lists
