<div>
  This is a <span>block</span> of html
</div>

<!--
  This is a comment
-->

<a href="http://example.com" title="This is an empty element" />

<a href="http://example.com"/>

<br />

This is normal text

* XML <i>element</i> in a list item

# XML <i>element</i> in an header

<div id="container">
XML/HTML could not contain *everything*

    Like code blocks

* Or
* List
* Items
</div>
