
* First level, first item

  # Header 1 in Level 1

  ## Header 2 in Level 1

  ### Header 3 in Level 1

  #### Header 4 in Level 1

  ##### Header 5 in Level 1

  ###### Header 6 in Level 1

  Hello
  ===

  * Level 2 list item

    # Header 1 in Level 2

    ## Header 2 in Level 2

    ### Header 3 in Level 2

  #### Header 4 in Level 1

  ##### Header 5 in Level 1

  ###### Header 6 in Level 1


* First level, first item, the following it's a rule

  ***
  * Second level, first item,, the following it's a rule

    ***

    * Third level, first item, the following it's not a rule because the preceding empty line it's mandatory
      ***

    * Third level, second item, the following it's not a rule because it's anchored at the exact indentation

        ***


* First level, first item, the following it's blockquote

  > Blockquotes terminates with an empty line

  * Second level, first item,, the following it's a blockquote

    > Blockquotes terminates with an empty line

    * Third level, first item, the following it's not a blockquote because the preceding empty line it's mandatory
      > Blockquotes terminates with an empty line

    * Third level, second item, the following it's not a rule because it's anchored at the exact indentation

        > Blockquotes terminates with an empty line

