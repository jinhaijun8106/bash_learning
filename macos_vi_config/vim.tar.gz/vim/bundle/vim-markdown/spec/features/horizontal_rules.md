The following are all horizontal rules

***

---

___

*********************

---------------------

_____________________


- - -

_ _ _

  * * *

 - - -


Now a special case

---
The line before is an horizontal rule
This is however is a title
---
